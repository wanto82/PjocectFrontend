export default {
    merchants: [],
    ajaxLoading: false
}